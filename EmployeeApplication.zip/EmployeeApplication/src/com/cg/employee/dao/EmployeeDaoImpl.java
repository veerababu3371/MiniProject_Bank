package com.cg.employee.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.ArrayList;






import org.apache.log4j.Logger;

import com.cg.employee.dto.CapRequest;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.util.DBUtil;
import com.cg.logger.MyLogger;



public class EmployeeDaoImpl implements EmployeeDao{
	
	Connection con;
	Logger logger;
	
	public EmployeeDaoImpl()
	{
		con = DBUtil.getConnect();
		logger =MyLogger.getLogger();
	}

	public int getEmployeeId()throws EmployeeException
	{
		logger.info("In getEmployeeId");
		int id = 0;
		String qry = "SELECT eId_seq.CURRVAL FROM DUAL";
			try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id = rs.getInt(1);
				logger.info("gotEmployee with Id "+id);
			}
			}
			catch(SQLException e)
			{
				logger.error("error"+e.getMessage());
				throw new EmployeeException(e.getMessage());
			}
			logger.info("completed getEmployeeId");
			return id;
		
	}
	@Override
	public int addEmployee(CapRequest emp) throws EmployeeException {
		// TODO Auto-generated method stub
		logger.info("In Add Employee");
		logger.info("input is"+emp);
		
		int id = 0;
		String qry = "INSERT INTO EmployeeJEE VALUES(eId_seq.NEXTVAL,?,?,?)";
		String name = emp.getEmpName();
		int sal = emp.getEmpSal();
		LocalDate bDate = emp.getbDate(); 
		java.sql.Date date = java.sql.Date.valueOf(bDate);
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setString(1, name);
			pstmt.setInt(2,sal);
			pstmt.setDate(3, date);
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				id = getEmployeeId();
				logger.info("Inserted successfully and id is="+id);
			}
			else
				throw new EmployeeException("unable to insert"+emp);
			
		}
		catch(SQLException e)
		{
			logger.error("error in insert"+e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		return id;
	}

	@Override
	public CapRequest removeEmployee(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		CapRequest emp = null;
		String qry = "DELETE FROM EmployeeJEE WHERE empId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, empId);
			emp = getEmployeeById(empId);
			int row = pstmt.executeUpdate();
			if(emp==null)
			{
				throw new EmployeeException("emp with id "+empId+"not found");
			}
			else if(row > 0)
			{
				System.out.println("Deleted Employee with Id "+empId);
				
			}
			
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return emp;
	}

	@Override
	public CapRequest getEmployeeById(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		CapRequest emp = null;
		String qry = "SELECT * FROM EmployeeJEE WHERE empId=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1, empId);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int sal = rs.getInt(3);
				java.sql.Date date = rs.getDate(4);
				java.time.LocalDate bDate = date.toLocalDate();
				emp = new CapRequest(id,name,sal,bDate);
			}
			else
				throw new EmployeeException("Employee with id "+empId+"not found");
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return emp;
	}

	@Override
	public ArrayList<CapRequest> getAllEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		ArrayList<CapRequest>list = new ArrayList<CapRequest>();
		String qry = "SELECT * FROM EmployeeJEE";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int sal = rs.getInt(3);
				java.sql.Date date = rs.getDate(4);
				LocalDate bDate = date.toLocalDate();
				CapRequest emp = new CapRequest(id,name,sal,bDate);
				list.add(emp);
			}
		}
		catch(SQLException e)
		{
			throw new EmployeeException(e.getMessage());
		}
		return list;
	}

	@Override
	public CapRequest updateEmployee(int empId, int empSal)
			throws EmployeeException {
		// TODO Auto-generated method stub
		CapRequest emp = getEmployeeById(empId);
		if(emp==null)
			throw new EmployeeException("Employee with id "+empId+"Not found");
		else
		{
			String qry = "UPDATE EmployeeJEE SET empSal=? WHERE empId=?";
			try{
				PreparedStatement pstmt = 
						con.prepareStatement(qry);
				pstmt.setInt(1, emp.getEmpSal()+empSal);
				pstmt.setInt(2, empId);
				int row = pstmt.executeUpdate();
				if(row > 0)
				{
					System.out.println("updated successfully");
					emp = getEmployeeById(empId);
				}      
			}
			catch(SQLException e)
			{
				throw new EmployeeException(e.getMessage());
			}
			
		}
		return emp;
	}

}





