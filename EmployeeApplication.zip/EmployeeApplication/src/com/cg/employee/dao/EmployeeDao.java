package com.cg.employee.dao;

import java.util.ArrayList;

import com.cg.employee.dto.CapRequest;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeDao {

	int addEmployee(CapRequest emp)throws EmployeeException;
	CapRequest removeEmployee(int empId)throws EmployeeException;
	CapRequest getEmployeeById(int empId)throws EmployeeException;
	ArrayList<CapRequest>getAllEmployee()throws EmployeeException;
	CapRequest updateEmployee(int empId,int empSal)throws EmployeeException;
	
}







