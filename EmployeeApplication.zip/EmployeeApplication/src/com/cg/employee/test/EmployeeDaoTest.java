package com.cg.employee.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.dto.CapRequest;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeServiceImpl;


public class EmployeeDaoTest 
{
 EmployeeServiceImpl service;
EmployeeDao dao =new EmployeeDaoImpl();
//EmployeeDao dao;

@Before

public void init()
	{
	dao = new EmployeeDaoImpl();
	service = new EmployeeServiceImpl();
	service.setDao(dao);
	}
public void testGetAllEmployee()throws EmployeeException
{
	ArrayList<CapRequest>list = service.getAllEmployee();
	assertNotNull(list);
}

@Test
public void testAddEmployee()throws EmployeeException
{
	CapRequest emp= new CapRequest();
	emp.setEmpName("Hina");
    emp.setEmpSal(40000);
    emp.setbDate(LocalDate.of(1988,Month.MAY,27));
    
    int id = service.addEmployee(emp);
    assertNotSame(id,0);
}


@Test
public void testDeleteEmployee() throws EmployeeException
{
	CapRequest emp= service.removeEmployee(2004);
	assertNotNull(emp);
}

@Test
public void updateEmployee() throws EmployeeException
{
	CapRequest emp =service.updateEmployee(2040, 2000);
	assertNotNull(emp);
}

@After

public void destory()
{
	dao =null;
	service=null;
}
}
